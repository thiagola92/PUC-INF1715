// Nome: Thiago Lages de Alencar
// Matricula: 1721629

#ifndef _TEST_
#define _TEST_

#include"monga.h"
#include"binding.h"
#include"type.h"

extern Node* __root__;

int test(const char* path);

#endif
